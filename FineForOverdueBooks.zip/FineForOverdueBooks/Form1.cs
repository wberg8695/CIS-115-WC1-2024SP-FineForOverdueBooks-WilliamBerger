namespace FineForOverdueBooks
{
    public partial class FineForOverdueBooks : Form
    {
        public FineForOverdueBooks()
        {
            InitializeComponent();
        }

        private void CalcButton_Click(object sender, EventArgs e)
        {
            int numBooks = Convert.ToInt32(booksBox.Text);
            int numDays = Convert.ToInt32(daysBox.Text);
            outputLabel.Text = Main(numBooks, numDays).ToString("C");
        }
        static double Main(int books, int days)
        {
            int limit = 7;
            double due = 0;
            double fee1 = 0.10 * books;
            double fee2 = 0.20 * books;
            double week1Fee = 0.70 * books;
            if (days > 0)
            {
                if (days < limit)
                {
                    for (int x = 0; x < days; ++x)
                    {
                        due += fee1;
                    }
                }
                else
                {
                    for (int x = days; x > limit; --x)
                    {
                        due += fee2;
                    }
                    due += week1Fee;
                }
            }
            return due;
        }

        private void OutputLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
