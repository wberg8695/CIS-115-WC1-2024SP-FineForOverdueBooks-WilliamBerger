﻿namespace FineForOverdueBooks
{
    partial class FineForOverdueBooks
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bookLabel = new Label();
            booksBox = new TextBox();
            daysBox = new TextBox();
            calcButton = new Button();
            daysLabel = new Label();
            outputLabel = new Label();
            SuspendLayout();
            // 
            // bookLabel
            // 
            bookLabel.AutoSize = true;
            bookLabel.Location = new Point(53, 53);
            bookLabel.Name = "bookLabel";
            bookLabel.Size = new Size(212, 20);
            bookLabel.TabIndex = 0;
            bookLabel.Text = "Number of books checked out:";
            // 
            // booksBox
            // 
            booksBox.Location = new Point(271, 53);
            booksBox.Name = "booksBox";
            booksBox.Size = new Size(62, 27);
            booksBox.TabIndex = 1;
            // 
            // daysBox
            // 
            daysBox.Location = new Point(235, 94);
            daysBox.Name = "daysBox";
            daysBox.Size = new Size(62, 27);
            daysBox.TabIndex = 2;
            // 
            // calcButton
            // 
            calcButton.Location = new Point(53, 140);
            calcButton.Name = "calcButton";
            calcButton.Size = new Size(114, 29);
            calcButton.TabIndex = 3;
            calcButton.Text = "Calculate Fees";
            calcButton.UseVisualStyleBackColor = true;
            calcButton.Click += CalcButton_Click;
            // 
            // daysLabel
            // 
            daysLabel.AutoSize = true;
            daysLabel.Location = new Point(53, 97);
            daysLabel.Name = "daysLabel";
            daysLabel.Size = new Size(176, 20);
            daysLabel.TabIndex = 4;
            daysLabel.Text = "Number of days overdue:";
            // 
            // outputLabel
            // 
            outputLabel.BorderStyle = BorderStyle.Fixed3D;
            outputLabel.Location = new Point(53, 193);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(176, 27);
            outputLabel.TabIndex = 5;
            outputLabel.Click += OutputLabel_Click;
            // 
            // FineForOverdueBooks
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(392, 283);
            Controls.Add(outputLabel);
            Controls.Add(daysLabel);
            Controls.Add(calcButton);
            Controls.Add(daysBox);
            Controls.Add(booksBox);
            Controls.Add(bookLabel);
            Name = "FineForOverdueBooks";
            Text = "Fine For Overdue Books";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label bookLabel;
        private TextBox booksBox;
        private TextBox daysBox;
        private Button calcButton;
        private Label daysLabel;
        private Label outputLabel;
    }
}
